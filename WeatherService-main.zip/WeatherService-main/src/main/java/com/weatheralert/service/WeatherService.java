package com.weatheralert.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.client.RestTemplate;

@Service
public class WeatherService {

    @Value("${weather.api.key}")
    private String apiKey;

    @Value("${weather.api.url}")
    private String apiUrl;

    public Map<String, Object> getWeather(String city) {
        RestTemplate restTemplate = new RestTemplate();

        // Build the URL as a string
        String url = apiUrl + "?q=" + city + "&appid=" + apiKey + "&units=metric";

        // Call the API and parse JSON into a Map
        Map<String, Object> response = restTemplate.getForObject(url, Map.class);

        return response;
    }
}
